ace.define("ace/snippets/twig",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "twig";

});
