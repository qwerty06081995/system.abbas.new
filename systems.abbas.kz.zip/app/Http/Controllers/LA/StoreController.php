<?php


namespace App\Http\Controllers\LA;


use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Overhead;

class StoreController extends Controller
{
    public $show_action = true;
    public function index(){
        $show_actions = $this->show_action;
        $orders  = Order::where('status', 'Курьер забрал')->where('courier_id', '!=', 0)->get();
        //dd($orders);
        return view('la.store.index', compact('orders', 'show_actions'));
    }

    public function show($id = 0){
        //dd($id);
        $order = Order::find($id);
        //dd($order);
        $overhead = Overhead::where('overhead_code', $order->overhead_id)->get()->first();
        //dd($overhead);
        return view('la.store.show', compact('order', 'overhead'));
    }

    public function check(){
        //echo $_GET['id'];
//        print_r($_GET);
//        die;
        $order_id = intval($_GET['id']);
        $overhead_id = intval($_GET['overhead_id']);
        $order = Order::find($order_id);
        if ($order->overhead_id == 0){
            $rand_id = rand(100000, 999999);
            $overhead = Overhead::create([
                'overhead_code'=>$overhead_id
            ]);
            if ($overhead){
                //$order_new = Order::where('id', $order_id)->update(['overhead_id', $rand_id]);
                $order->overhead_id = $overhead_id;
                $order->save();
                //print_r($order_new->first());
                //$order_new->first()->update(['overhead_id', $rand_id]);
                return json_encode(['success'=>2]);
            }

        }else{
            return json_encode(['success'=>1]);
        }
    }

}